<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<!--	<base href="../">--><!-- то есть выйти из "www/" и попасть в корень"/" -->
	<title>Мой блог</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>

<table class="layout">
	<tr>
		<td colspan="2" class="header">
			Мой блог
		</td>
	</tr>
	<tr>
		<td>