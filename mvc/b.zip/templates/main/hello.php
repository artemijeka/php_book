<?php include __DIR__ . '/header.php'; ?>
	Привет, <?= $name ?>!!!
<?php include __DIR__ . '/footer.php'; ?>