<?php
/**
 * Created by PhpStorm.
 * User: artem
 * Date: 17.10.18
 * Time: 9:05
 */

/**
 * Данный config.php обязательно лежит в самом корне веб-приложения.
 */
//const BASE_STYLE_DIR = __DIR__.'/www/css/';