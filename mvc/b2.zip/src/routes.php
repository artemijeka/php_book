<?php
/**
 * Created by PhpStorm.
 * User: artem
 * Date: 20.10.18
 * Time: 8:51
 */
return [
    '~^hello/(.*)$~' => [\MyProject\Controllers\MainController::class, 'sayHello'],
    '~^$~' => [\MyProject\Controllers\MainController::class, 'main'],
];