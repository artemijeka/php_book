<?php
/**
 * Created by PhpStorm.
 * User: artem
 * Date: 20.10.18
 * Time: 8:26
 */
spl_autoload_register(function (string $className) {
    require_once __DIR__ . "/../src/" . str_replace('\\', '/', $className) . ".php";
});

$route = $_GET['route'] ?? '';
$routes = require __DIR__ . '/../src/routes.php';
//var_dump($routes);

$isRouteFound = false;
foreach ($routes as $pattern => $controllerAndAction) {
    preg_match($pattern, $route, $matches);
    if (!empty($matches)) {
        $isRouteFound = true;
        break;
    }
}

//var_dump($controllerAndAction);

if (!$isRouteFound) {
    echo 'Страница не найдена!';
    return;
}

unset($matches[0]);

$controllerName = $controllerAndAction[0];
$actionName = $controllerAndAction[1];

$controller = new $controllerName();
$controller->$actionName(...$matches);

//$controllerName = $controllerAndAction[0];
//$actionName = $controllerAndAction[1];
//
//$controller = new $controllerName();
//$controller->$actionName();

//$route = $_GET['route'] ?? '';
//
//$pattern = '~^hello/(.*)$~';
//preg_match($pattern, $route, $matches);
//
//if (!empty($matches)) {
//    $controller = new \MyProject\Controllers\MainController();
//    $controller->sayHello($matches[1]);
//    return;
//}
//
//$pattern = '~^$~';
//preg_match($pattern, $route, $matches);
//
//if (!empty($matches)) {
//    $controller = new \MyProject\Controllers\MainController();
//    $controller->main();
//    return;
//}
//
//echo 'Страница не найдена';

//$controller = new \MyProject\Controllers\MainController();
//
//if (!empty($_GET['name'])) {
//    $controller->sayHello($_GET['name']);
//} else {
//    $controller->main(); // echo 'Главная страница';
//}